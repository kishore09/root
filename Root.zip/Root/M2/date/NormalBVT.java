package next;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class NormalBVT {

@Test
public void test1() {
datepro d = new datepro(1, 6, 1919); 
assertEquals("2/6/1919", d.compute());
}

@Test
public void test2() {
datepro d = new datepro(16, 6, 1919);
assertEquals("17/6/1919", d.compute());
}

@Test
public void test3() {
datepro d = new datepro(16, 1, 1819);
assertEquals("17/1/1819", d.compute());
}

@Test
public void test4() {
datepro d = new datepro(16, 6, 2009); 
assertEquals("17/6/2009", d.compute());
}

@Test
public void test5() {
datepro d = new datepro(31, 6, 2009);
assertEquals("Date not in range", d.compute());
}
}
