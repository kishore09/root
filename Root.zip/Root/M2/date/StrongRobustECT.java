package next;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class StrongRobustECT {

	@Test
	public void test1() {
	datepro d = new datepro(0, 6, 1919);
	assertEquals("Day not in range", d.compute());
	}

	@Test
	public void test2() {
	datepro d = new datepro(16, 0, 1919); 
	assertEquals("month not in range", d.compute());
	}

	@Test
	public void test3() {
	datepro d = new datepro(16, 1, 2020); 
	assertEquals("year not in range", d.compute());
	}

	@Test
	public void test4() {
	datepro d = new datepro(32, -1, 1919);
	assertEquals("Day,month not in range", d.compute());
	}

	@Test
	public void test5() {
	datepro d = new datepro(16, 13, 2020); 
	assertEquals("month,year not in range", d.compute());
	}


	@Test
	public void test6() {
	datepro d = new datepro(-1, 1, 1818);
	assertEquals("day,year not in range", d.compute());
	}


	@Test
	public void test7() {
	datepro d = new datepro(-1, -1, 1818);
	assertEquals("Day,month,year not in range", d.compute());
	}
	}

