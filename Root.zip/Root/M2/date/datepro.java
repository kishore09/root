package next;

public class datepro
{
int m,d,y;
public datepro(int x,int h,int z){ d=x;
m=h; y=z;
}
static int leap(int year){
if(year%400==0 ||year%100==0 ||year%4==0) return 1;
else return 0;
}
public String compute(){ 
String s="";
int td=d,tm=m,ty=y;
if((d<1 || d>31) && (m<1 ||m>12) && (y<1819 || y>2019))
	s=s+"Day,month,year not in range";
else if((d<1 || d>31) && (m<1 ||m>12)) 
	s=s+"Day,month not in range";
else if((m<1 ||m>12) && (y<1819 || y>2019))
	s=s+"month,year not in range";
else if((d<1 ||d>31) && (y<1819 || y>2019)) 
	s=s+"day,year not in range";
else if((d<1 || d>31)) 
	s=s+"Day not in range"; 
else if((m<1 || m>12))
	s=s+"month not in range"; 
else if((y<1819 || y>2012))
	s=s+"year not in range"; else{
if(m==1 || m==3 || m==5 ||m==7 ||m==8|| m==10){ if(d<31)
td=td+1; 
else{
	td=1;
	tm=tm+1;
}
}
else if(m==4 || m==6 || m==9 ||m==11){ if(d==31)
s=s+"Date not in range";
else if(d<30)
td=d+1;
else
{ 
	td=1;
	tm=m+1;
}
}
else if(m==12)
{
	if(d<31) td=d+1;
else{
	if(y>=2019)
s=s+"Date not in range"; 
	else{
td=1;
tm=1;
ty=y+1;
}  }  }
else{
if(d==30 || d==31) 
	s=s+"Date not in range";
else if(d==28)
{
	if(leap(y)==1)
td=d+1;
	else{ 
		td=1;
		tm=3;
} }
else if(d==29 && leap(y)==1)
{
td=1; tm=3;
}
else if(d<28) td=d+1;
else
s=s+"Date not in range";
} }
if(s.length()==0) s=td+"/"+tm+"/"+ty; return s;
}
}
