package next;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class WeakRobustECT {

	@Test
	public void test1() {
	datepro d = new datepro(0, 6, 1919);
	assertEquals("Day not in range", d.compute());
	}

	@Test
	public void test2() {
	datepro d = new datepro(16, 0, 1919);
	assertEquals("month not in range", d.compute());
	}

	@Test
	public void test3() {
	datepro d = new datepro(16, 1, 2020); 
	assertEquals("year not in range", d.compute());
	}

	@Test
	public void test4() {
	datepro d = new datepro(16, 6, 2009);
	assertEquals("17/6/2009", d.compute());
	}

	@Test
	public void test5() {
	datepro d = new datepro(31, 6, 2009); 
	assertEquals("Date not in range", d.compute());
	}
	}

