package nextdate;

import static org.junit.Assert.*;
import org.junit.Test;

public class nextdateTest {

    @Test
    public void test2d_1() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(1, 10, 1919), "2.10.1919");
    }

    @Test
    public void test2d_2() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(16, 1, 1819), "17.1.1819");
    }

    @Test
    public void test2d_3() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(16, 6, 1819), "17.6.1819");
    }

    @Test
    public void test2d_4() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(16, 7, 1825), "17.7.1825");
    }

    @Test
    public void test2d_5() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(31, 5, 1872), "1.6.1872");
    }

    @Test
    public void test2d_6() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(17, 8, 2001), "18.8.2001");
    }

    @Test
    public void test2d_7() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(16, 6, 1819), "17.6.1819");
    }

    @Test
    public void test2d_8() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(16, 6, 2009), "17.6.2009");
    }

    @Test
    public void test2d_9() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(0, 6, 1919), "Invalid Input");
    }

    @Test
    public void test2d_10() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(16, 0, 1819), "Invalid Input");
    }

    @Test
    public void test2d_11() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(32, 4, 1818), "Invalid Input");
    }

    @Test
    public void test2d_12() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(16, 6, 2009), "17.6.2009");
    }

    @Test
    public void test2d_13() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(-1, 16, 2020), "Invalid Input");
    }

    @Test
    public void test2d_14() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(16, -1, 1819), "Invalid Input");
    }

    @Test
    public void test2d_15() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(-1, -1, 1919), "Invalid Input");
    }

    @Test
    public void test2d_16() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(32, -1, 2009), "Invalid Input");
    }

    @Test
    public void test2d_17() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(16, -1, 2020), "Invalid Input");
    }

    @Test
    public void test2d_18() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(-1, 6, 2020), "Invalid Input");
    }

    @Test
    public void test2d_19() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(-1, -1, 2020), "Invalid Input");
    }

    @Test
    public void test2d_20() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(16, 6, 2009), "17.6.2009");
    }

    @Test
    public void test2d_21() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(28, 5, 2009), "29.5.2009");
    }

    @Test
    public void test2d_22() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(31, 5, 2009), "1.6.2009");
    }

    @Test
    public void test2d_23() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(30, 4, 2009), "1.5.2009");
    }

    @Test
    public void test2d_24() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(15, 9, 2019), "16.9.2019");
    }

    @Test
    public void test2d_25() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(15, 11, 2019), "16.11.2019");
    }

    @Test
    public void test2d_26() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(15, 3, 1864), "16.3.1864");
    }

    @Test
    public void test2d_27() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(31, 4, 1819), "Invalid Input");
    }

    @Test
    public void test2d_28() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(31, 2, 1819), "Invalid Input");
    }

    @Test
    public void test2d_29() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(27, 2, 1900), "28.2.1900");
    }

    @Test
    public void test2d_30() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(28, 2, 2000), "29.2.2000");
    }

    @Test
    public void test2d_31() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(21, 2, 1902), "22.2.1902");
    }

    @Test
    public void test2d_32() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(29, 2, 2000), "1.3.2000");
    }

    @Test
    public void test2d_33() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(30, 2, 2000), "Invalid Input");
    }

    @Test
    public void test2d_34() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(12, 2, 2004), "13.2.2004");
    }

    @Test
    public void test2d_35() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(28, 2, 2003), "1.3.2003");
    }

    @Test
    public void test2d_36() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(31, 12, 2003), "1.1.2004");
    }

    @Test
    public void test2d_37() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(30, 12, 2003), "31.12.2003");
    }

    @Test
    public void test2d_38() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(15, 2, 1900), "16.2.1900");
    }

    @Test
    public void test2d_39() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(16, 16, 1819), "Invalid Input");
    }

    @Test
    public void test2d_40() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(6, 6, 1817), "Invalid Input");
    }

    @Test
    public void test2d_41() {
        nextdate obj = new nextdate();
        assertEquals(obj.nextdate(16, 1, 2020), "Invalid Input");
    }
}