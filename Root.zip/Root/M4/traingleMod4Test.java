package traingleMod4;

import static org.junit.Assert.*;
import org.junit.Test;

public class traingleMod4Test {

	triangleMod4 t = new triangleMod4();

	@Test
	public void test1() {
		String status = t.compute(10, 20, 40);
		assertEquals("invalid triangle", status);
	}

	@Test
	public void test2() {
		String status = t.compute(10, 20, 30);
		assertEquals("invalid triangle", status);
	}

	@Test
	public void test3() {
		String status = t.compute(60, 20, 30);
		assertEquals("invalid triangle", status);
	}

	@Test
	public void test4() {
		String status = t.compute(50, 20, 30);
		assertEquals("invalid triangle", status);
	}

	@Test
	public void test5() {
		String status = t.compute(10, 40, 20);
		assertEquals("invalid triangle", status);
	}

	@Test
	public void test6() {
		String status = t.compute(10, 30, 20);
		assertEquals("invalid triangle", status);
	}

	@Test
	public void test7() {
		String status = t.compute(10, 10, 10);
		assertEquals("equilateral triangle", status);
	}

	@Test
	public void test8() {
		String status = t.compute(5, 4, 3);
		assertEquals("scalene triangle", status);
	}

	@Test
	public void test9() { // iso has 3 again
		String status = t.compute(2, 2, 3);
		assertEquals("isosceles triangle", status);
	}

	@Test
	public void test10() {
		String status = t.compute(1, 2, 2);
		assertEquals("isosceles triangle", status);
	}

	@Test
	public void test11() {
		String status = t.compute(2, 1, 2);
		assertEquals("isosceles triangle", status);
	}

}
