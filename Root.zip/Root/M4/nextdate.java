package nextdate;

public class nextdate {
    String nextdate(int date, int month, int year) {
        if ((date >= 1 && date <= 31) && (month >= 1 && month <= 12) && (year >= 1819 && year <= 2019)) {
            if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10) {
                if (date < 31) {
                    date = date + 1;
                } else {
                    date = 1;
                    month = month + 1;
                }
            } else if (month == 4 || month == 6 || month == 9 || month == 11) {
                if (date < 30) {
                    date = date + 1;
                } else if (date == 30) {
                    date = 1;
                    month = month + 1;
                } else {
                    return "Invalid Input";
                }
            } else if (month == 2) {
                if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
                    if (date <= 28)
                        date = date + 1;
                    else if (date == 29) {
                        date = 1;
                        month = month + 1;
                    } else
                        return "Invalid Input";
                } else {
                    if (date < 28)
                        date = date + 1;
                    else if (date == 28) {
                        date = 1;
                        month = month + 1;
                    } else
                        return "Invalid Input";
                }
            }

            else {
                if (date < 31)
                    date = date + 1;
                else {
                    month = 1; // -----> imp
                    date = 1;
                    year = year + 1;
                }
            }
            String day = date + "." + month + "." + year;
            return day;
        } else {
            return "Invalid Input";
        }
    }
}