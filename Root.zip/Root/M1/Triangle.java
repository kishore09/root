package triangle;
import java.util.Scanner;
public class Triangle {

	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter three sudes of a triangle");
		int a = sc.nextInt();
		if(a<1||a>200)
		{
			System.out.println("A out of range");
		}
		int b = sc.nextInt();
		if(b<1 || b>200)
		{
			System.out.println("B out of range");
		}
			int c = sc.nextInt();
			if(c<1||c>200)
			{
				System.out.println("C out of range");
			}
			else{
				if(a<(b+c) && b<(a+c) && c<(a+b))
				{
					if(a==b && a==c)
					{
						System.out.println("Equilateral Triangle");
					}
					else if(a!=b && b!=c && a!=c)
					{
						System.out.println("Scalene Triangle");
					}
					else
						System.out.println("Isosceles Triangle");
				}
				else
				{
					System.out.println("Not a Triangle");
				}
			}


	}
}
