
import javax.swing.*;
import java.awt.event.*;

public class currency_Converter extends JFrame implements ActionListener{

   JLabel l1= new JLabel("Currency Converter");
   JLabel l2= new JLabel("US Dollar Amount");
   JLabel l3= new JLabel("Equivalence in...");
   JTextField ip= new JTextField();
   JTextField op= new JTextField();
   JButton b1= new JButton("COMPUTE");
   JButton b2= new JButton("CLEAR");
   JButton b3= new JButton("QUIT");

   JRadioButton r1=new JRadioButton("Brazil");
   JRadioButton r2=new JRadioButton("Canada");
   JRadioButton r3=new JRadioButton("Europian Community");
   JRadioButton r4=new JRadioButton("Japan");

	public currency_Converter()
	{
		setSize(600,400);
		setLayout(null);
		setVisible(true);
		l1.setBounds(200,0,150,50);
		l2.setBounds(50,80,100,50);
		l3.setBounds(50,110,100,50);
		ip.setBounds(180,80,150,25);
		op.setBounds(180,110,150,25);
		r1.setBounds(50,150,100,20);
		r2.setBounds(50,190,100,20);
		r3.setBounds(50,230,200,20);
		r4.setBounds(50,270,100,20);
		b1.setBounds(400,180,100,30);
		b2.setBounds(400,240,100,30);
		b3.setBounds(400,300,100,30);

		ButtonGroup bg= new ButtonGroup();
		bg.add(r1);
		bg.add(r2);
		bg.add(r3);
		bg.add(r4);

	  add(b1);
	  add(b2);
	  add(b3);
		add(r1);
		add(r2);
		add(r3);
		add(r4);
		add(l1);
		add(l2);
		add(l3);
		add(ip);
		add(op);
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);

	}

@Override
public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b1)
    {
			int f=0;
			String str= ip.getText().toString();
			if(str.length()>10)
			op.setText("Too large number");
			else
      {
    			for(int i=0;i<str.length();i++)
    			{
    				if(!Character.isDigit(str.charAt(i))&& !Character.isLetter(str.charAt(i)))
    				{
    					op.setText("Symbols not allowed");
    				}
    			}
    			Double x= Double.valueOf(str);

    			Double y=0.0;
    			if(r1.isSelected())
    			{
    			  	y=x *4.09;
    			}
    			if(r2.isSelected())
    			{
    				y=x *1.33;
    			}
    			if(r3.isSelected())
    			{
    				y=x *0.90;
    			}
    			if(r4.isSelected())
    			{
    				y=x *108.08;
    			}
    			op.setText(String.valueOf(y));
		}
  }
        if(e.getSource()==b2) {
        	ip.setText("");
        	op.setText("");
		}
        if(e.getSource()==b3) {
        	System.exit(0);

        }
	}

	public static void main(String[] args) {
		currency_Converter cc = new currency_Converter();

	}

}
