package atm;
import java.util.*;

class AtmProgram
{
	int amt=1000,n,ch,p=0;
	Scanner sc=new Scanner(System.in);

	public void getdata(){   // --------> 1
		System.out.println("please enter your pin");
		int pin=sc.nextInt();
		if(pin==1234){
			account();
		}
		else{
			p++;
			if(p<3){
				System.out.println("Invalid pin number please try again");
				getdata();
			}
			else
				System.out.println("Your card is blocked!!!!");
		}
	}

	public void account(){    // --------> 2
		System.out.println("enter 1.current 2.saving");
		int x=sc.nextInt();
		if(x!=1 && x!=2){
			System.out.println("invalid account type");
			System.exit(0);
			//return;
		}
		else
			 calculate();
	}

	public void calculate(){		 // --------> 3
		System.out.println("enter \n 1.Balance Enquiry\n2.withdraw\n3.deposit\n4.exit");
		ch=sc.nextInt();
		switch(ch){
		case 1:balance();
			break;
		case 2:withdraw();
			break;
		case 3:deposit();
			break;
		case 4:System.out.println("Please take your card and receipt thank you");
		     // return;
		      System.exit(0);
		      break;
		 default:System.out.println("Enter a valid choice");
		 break;
		}
	}

	public void balance(){		 // --------> 4
		System.out.println("Balance="+amt);
		calculate();
	}

	public void withdraw(){		 // --------> 5
		System.out.println("Enter amount to be withdrawn");
		n=sc.nextInt();
		if(n>amt)
		{
			System.out.println("Insufficient amount");
		}
		else{
			amt=amt-n;
		}
		calculate();
	}

	public void deposit(){		 // --------> 6
		System.out.println("Enter the amount to deposit");
		n=sc.nextInt();
		amt=amt+n;
		calculate();
	}
}


public class Atm {

	public static void main(String[] args) {

         System.out.println("Welcome to bank please insert your atm card");
         AtmProgram a=new AtmProgram();
         a.getdata();
	}

}
