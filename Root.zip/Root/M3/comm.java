package comm;
public class comm {

	int calc(int lock,int stock,int barrel)
	{
	   if(lock>0 && stock>0 && barrel>0)
	   {
		int sales=0;
		sales= (lock*45)+ (stock*30)+(barrel*25);
		
		if(sales<=1000)
			return (int)(0.1*sales);
		
		else if(sales>1800)
			return (int)((0.1*1000)+ 0.15*(800)+ 0.2*(sales-1800)); 
			
		else return (int)((0.1*1000)+ 0.15*(sales-1000));
		 
	   }
	   else return -1; 
	}
	
}
