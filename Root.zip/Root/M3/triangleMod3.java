package triangle;

public class triangleMod3 {
	
		
		String compute(int a, int b, int c) {
			
			//checking validity
			if((a+b)<=c || (b+c)<=a || (a+c)<=b)
			{
				
				 return "invalid triangle";
				
			}
			else
			{
				if((a==b)&&(b==c))
					return "equilateral triangle";
				else if(a==b||b==c||a==c)
					return "isosceles triangle";
				else return "scalene triangle";
			}
	        
			
			
			
			
			
			
		}

	}




