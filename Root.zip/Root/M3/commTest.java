package comm;

import static org.junit.Assert.*;
import org.junit.Test;

public class commTest {

    @Test
    public void test1() {
        comm cc = new comm();
        int ans = cc.calc(-1, 2, 3);
        assertEquals(-1, ans);

    }

    @Test
    public void test2() {
        comm cc = new comm();
        int ans = cc.calc(3, -1, 10);
        assertEquals(-1, ans);

    }

    @Test
    public void test3() {
        comm cc = new comm();
        int ans = cc.calc(1, 3, -10);
        assertEquals(-1, ans);
    }

    @Test
    public void test4() {
        comm cc = new comm();
        int ans = cc.calc(1, 1, 1);
        assertEquals(10, ans); // remember the ans
    }

    @Test
    public void test5() {
        comm cc = new comm();
        int ans = cc.calc(18, 19, 18);
        assertEquals(226, ans); // remember the ans -> 23/3 22/6
    }

    @Test
    public void test6() {
        comm cc = new comm();
        int ans = cc.calc(14, 14, 14);
        assertEquals(160, ans); // remember the ans ->14,15,16 160
    }

}
