import static org.junit.Assert.*;

import org.junit.Test;

public class mod {
    @Test
    public void test() {
        Vowels v = new Vowels();
        String a = v.check('C');
        assertEquals("Consonant", a);
    }

    @Test
    public void test1() {
        Vowels v = new Vowels();
        String a = v.check('A');
        assertEquals("Vowel", a);
    }

    @Test
    public void test3() {
        Vowels v = new Vowels();
        String a = v.check('a');
        assertEquals("Vowel", a);
    }

    @Test
    public void test4() {
        Vowels v = new Vowels();
        String a = v.check('c');
        assertEquals("Consonant", a);
    }
}
