package nextpractise;

import static org.junit.Assert.*;

import org.junit.Test;

public class Nextdatepractisetestcases{
@Test
public void test2d_1()
{
NextDatePractise obj= new NextDatePractise(1,10,1919);
equals("2.10.1919");
}
@Test
public void test2d_2()
{
NextDatePractise obj= new NextDatePractise(16,1,1819);
equals("17.1.1819");
}
@Test
public void test2d_3()
{
NextDatePractise obj= new NextDatePractise(16,6,1819);
equals("17.6.1819");
}
@Test
public void test2d_4()
{
NextDatePractise obj= new NextDatePractise(16,7,1825);
equals("17.7.1825");
}
@Test
public void test2d_5()
{
NextDatePractise obj= new NextDatePractise(31,5,1872);
equals("1.6.1872");
}
@Test
public void test2d_6()
{
NextDatePractise obj= new NextDatePractise(17,8,2001);
equals("18.8.2001");
}
@Test
public void test2d_7()
{
NextDatePractise obj= new NextDatePractise(16,6,1819);
equals("17.6.1819");
}
@Test
public void test2d_8()
{
NextDatePractise obj= new NextDatePractise(16,6,2009);
equals("17.6.2009");
}
@Test
public void test2d_9()
{
NextDatePractise obj= new NextDatePractise(0,6,1919);
assertEquals("Day not in range",obj.compute());
}
@Test
public void test2d_10()
{
NextDatePractise obj= new NextDatePractise(16,0,1819);
assertEquals("month not in range",obj.compute());
}
@Test
public void test2d_11()
{
NextDatePractise obj= new NextDatePractise(32,4,1818);
assertEquals("Day,year not in range",obj.compute());
}
@Test
public void test2d_12()
{
NextDatePractise obj= new NextDatePractise(16,6,2009);
equals("17.6.2009");
}
@Test
public void test2d_13()
{
NextDatePractise obj= new NextDatePractise(-1,16,2020);
assertEquals("Day,month,year not in range",obj.compute());
}
@Test
public void test2d_14()
{
NextDatePractise obj= new NextDatePractise(16,-1,1819);
assertEquals("month not in range",obj.compute());
}
@Test
public void test2d_15()
{
NextDatePractise obj= new NextDatePractise(-1,-1,1919);
assertEquals("Day,month not in range",obj.compute());
}
@Test
public void test2d_16()
{
NextDatePractise obj= new NextDatePractise(32,-1,2009);
assertEquals("Day,month not in range",obj.compute());
}
@Test
public void test2d_17()
{
NextDatePractise obj= new NextDatePractise(16,-1,2020);
assertEquals("month,year not in range",obj.compute());
}
@Test
public void test2d_18()
{
NextDatePractise obj= new NextDatePractise(-1,6,2020);
assertEquals(obj.compute(),"Day,year not in range");
}
@Test
public void test2d_19()
{
NextDatePractise obj= new NextDatePractise(-1,-1,2020);
assertEquals(obj.compute(),"Day,month,year not in range");
}
@Test
public void test2d_20()
{
NextDatePractise obj= new NextDatePractise(16,6,2009);
equals("17.6.2009");
}
@Test
public void test2d_21()
{
NextDatePractise obj= new NextDatePractise(28,5,2009);
equals("29.5.2009");
}
@Test
public void test2d_22()
{
NextDatePractise obj= new NextDatePractise(31,5,2009);
equals("1.6.2009");
}
@Test
public void test2d_23()
{
NextDatePractise obj= new NextDatePractise(30,4,2009);
equals("1.5.2009");
}
@Test
public void test2d_24()
{
NextDatePractise obj= new NextDatePractise(15,9,2019);
equals("16.9.2019");
}
@Test
public void test2d_25()
{
NextDatePractise obj= new NextDatePractise(15,11,2019);
equals("16.11.2019");
}
@Test
public void test2d_26()
{
NextDatePractise obj= new NextDatePractise(15,3,1864);
equals("16.3.1864");
}
@Test
public void test2d_27()
{
NextDatePractise obj= new NextDatePractise(31,4,1819);
assertEquals(obj.compute(),"Date not in range");
}
@Test
public void test2d_28()
{
NextDatePractise obj= new NextDatePractise(31,2,1819);
assertEquals(obj.compute(),"Date not in range");
}
@Test
public void test2d_29()
{
NextDatePractise obj= new NextDatePractise(27,2,1900);
equals("28.2.1900");
}
@Test
public void test2d_30()
{
NextDatePractise obj= new NextDatePractise(28,2,2000);
equals("29.2.2000");
}
@Test
public void test2d_31()
{
NextDatePractise obj= new NextDatePractise(21,2,1902);
equals("22.2.1902");
}
@Test
public void test2d_32()
{
NextDatePractise obj= new NextDatePractise(29,2,2000);
equals("1.3.2000");
}
@Test
public void test2d_33()
{
NextDatePractise obj= new NextDatePractise(30,2,2000);
assertEquals(obj.compute(),"Date not in range");
}
@Test
public void test2d_34()
{
NextDatePractise obj= new NextDatePractise(12,2,2004);
equals("13.2.2004");
}
@Test
public void test2d_35()
{
NextDatePractise obj= new NextDatePractise(28,2,2003);
equals("1.3.2003");
}
@Test
public void test2d_36()
{
NextDatePractise obj= new NextDatePractise(31,12,2003);
equals("1.1.2004");
}
@Test
public void test2d_37()
{
NextDatePractise obj= new NextDatePractise(30,12,2003);
equals("31.12.2003");
}
@Test
public void test2d_38()
{
NextDatePractise obj= new NextDatePractise(15,2,1900);
equals("16.2.1900");
}
@Test
public void test2d_39()
{
NextDatePractise obj= new NextDatePractise(16,16,1819);
assertEquals(obj.compute(),"month not in range");
}
@Test
public void test2d_40()
{
NextDatePractise obj= new NextDatePractise(6,6,1817);
assertEquals(obj.compute(),"year not in range");
}
@Test
public void test2d_41()
{
NextDatePractise obj= new NextDatePractise(16,1,2020);
assertEquals(obj.compute(),"year not in range");
}
}
